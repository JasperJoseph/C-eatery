import React from 'react';
import {
    View,
    Text,
    Image
}from 'react-native';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { SafeAreaView } from 'react-native-safe-area-context';


export default function About(navigation){
    return(
        <SafeAreaView>
        <TouchableOpacity
        style={{
            left:30,
            width:40,
            marginTop:50,

        }}
        onPress={()=>{navigation.navigation.goBack()}}
        >
            <Image style={{
                height:25,
                width:25,
            }}
            source={require('../images/back.png')}
            ></Image>
        </TouchableOpacity>
        <View
        style={{
        }}
        >
        <View
        style={{
            marginTop:'65%',
            paddingLeft:29,
            textAlign:'center'
        }}
        >
            {/* <Text
            style={{
                marginTop:10,
                letterSpacing:10,
                textAlign:'center'
            }}
            > ¶~Shelton.</Text>
             */}

            <Text
            style={{
                marginTop:10,
                fontSize:11,
                textAlign:'left'
            }}
            >|| JOSEPH MAINA GATHII		I132/0477/2018.</Text>
            
            <Text
            style={{
                marginTop:10,
                fontSize:11,
                textAlign:'left'
            }}
            >|| DAVID KAMAU WANJIRU    	I132/0495/2018.</Text>
            
            <Text
            style={{
                marginTop:10,
                fontSize:11,
                textAlign:'left'
            }}
            >|| EKITELA BOYO PETER 		I132/0492/2018.</Text>

             <Text
            style={{
                bottom:0,
                fontSize:7,
                textAlign:'left'
            }}
            >under the guidance of Prof GEORGE RABURU</Text>
        </View>
        </View></SafeAreaView>
    )
}
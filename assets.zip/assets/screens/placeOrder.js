import React, { Component } from "react";
import {View,Text,SafeAreaView,Image,TextInput,StyleSheet,TouchableOpacity,Animated} from 'react-native';

import { useNavigation } from '@react-navigation/native';


interface AbcState {
    FullName: any;
    PhoneNo: any;
    RoomNo: any;
  }

export default class placeOrder extends Component <{},AbcState>{
  
    constructor(props:any) {
    super(props);
    this.state = { FullName: '', PhoneNo: '', RoomNo: '' };
    
  }
  
  
  insertRecord=()=>{
    var FullName = this.state.FullName;
    var PhoneNo =this.state.PhoneNo;
    var RoomNo = this.state.RoomNo;

    if(FullName.length == 0 || PhoneNo == 0|| RoomNo == 0){
      alert('required fields missing');
    }else{
      var insertAPIURL = "https://social-ci.org/chafua/pushOrder.php";

      var headers= {
        'Accept':'applicaiton/json',
        'Content-Type':'applicaiton/json'
      };
      var Data ={
        PhoneNo:PhoneNo,
        RoomNo:RoomNo,
        FullName:FullName,
      };
      fetch(insertAPIURL,{
        method:'POST',
        headers:headers,
        body:JSON.stringify(Data)
      })
      .then((response)=>response.json())
      .then((response)=>{
          if(!response[0].Message){
              <Text>item</Text>
          }else{
        alert(response[0].Message)}
      })
      .catch((error)=>
      {
        alert("Error"+error);
      })
    }
  }
  

    render(){
        return(
            <SafeAreaView
            
        style={{
            backgroundColor: 'white',
            flex: 1,
            paddingTop: 20,
            alignItems: 'center',
            justifyContent: 'center',
          }}>

        <Text style={{ color: 'orange' }}>Description</Text>

        <View style={styles.desc}>
        
          <Text>Text 1</Text>
          <Text>Text 1</Text>
          <Text>Text 1</Text>
        </View>
        <Text
          style={{
            marginTop: 50,
            color: 'orange',
          }}>
          Place Order
        </Text>
        <View>
          <TextInput
            style={styles.input}
            placeholder="Full Name"
            onChangeText={(FullName) => this.setState({ FullName })}
          />
          <TextInput
            style={styles.input}
            keyboardType="numeric"
            placeholder="Phone Number"
            onChangeText={(PhoneNo) => this.setState({ PhoneNo })}
          />
          <TextInput
            style={styles.input}
            placeholder="Room Number"
            onChangeText={(RoomNo) => this.setState({ RoomNo })}
          />
        </View>
        <View
          style={{
            borderColor: 'transparent',
            borderWidth: 2,
            height: 40,
          }}
        />
        <TouchableOpacity
            style={{
                width:  300,
                height:40,
                backgroundColor: "orange",
                alignItems: 'center',
                justifyContent:'center',
                borderRadius: 5
            }}
            onPress={this.insertRecord}
        
        >
            <Text style={{ color: "black" }}>Order</Text>
        </TouchableOpacity>
            </SafeAreaView>
        )
    }
}

const styles = StyleSheet.create({
    desc: {
      padding: 10,
      marginTop: 10,
      borderStyle: 'solid',
      borderWidth: 1,
      borderColor: 'grey',
      height: 100,
      width: 250,
    },
    input: {
        width:300,
      padding: 5,
      marginTop: 20,
      borderStyle: 'solid',
      borderColor: 'grey',
    },
  });

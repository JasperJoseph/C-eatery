import React, { Component,useState,useEffect } from 'react';
import {
  View,
  ScrollView,
  FlatList,
  StyleSheet,
  Image,
  Text,
  TouchableOpacity,
  ActivityIndicator,
  SafeAreaView,
  TextInput,
  RefreshControl,
  Touchable
} from 'react-native';
// const cartList = this.useRoute().params

function cart({ route, navigation }) {
    /* 2. Get the param */  
    
    const cartList = route.params;
    // const hotelName = route.params.hotelName;
    let [cartItems, setCartItems] = useState(cartList)
    let [refreshing, setRefreshing] = useState(false)
    let key = true
    let _key = false
    function _onRefresh(){
        setRefreshing(true)
        setRefreshing(false)
    }
    return (
        <SafeAreaView style={{backgroundColor:"#FFFFFF",minHeight:"100%",padding:20}}>
            <View
            style={{
                position:'absolute',
                width:'1150%',
                left:0,
                height:100,
                marginTop:0,
                backgroundColor:"#FFFFFF",
                zIndex:19
            }}/>
            <TouchableOpacity
            style={{
                position:'absolute',
                zIndex:20,
                marginTop:60,
                marginLeft:20
            }}
            onPress={()=>{
                navigation.goBack()
            }}
            >
            <Image style={{
                height:35,
                width:35
            }}
            source={require('../images/back.png')}
            />
            </TouchableOpacity>

<View 
                style={{marginTop:40,height:'85%',paddingBottom:50}}
>
      <FlatList
                data={cartItems}
                keyExtractor={itemID => itemID.ListID.toString()}
                renderItem={({item}) =>
                <View style={Styles.ord_box}>
                <Text>{item.name}</Text>
                <Text>{item.price}</Text>
                
                <TouchableOpacity
                style={{height:20,
                width:20,
                borderBottomWidth:1,
                marginTop:20,
                textAlign:'center'
                }}
                onPress={()=>{
                item.number = item.number + 1
                // console.log(item)
                // _onRefresh()
                setRefreshing(false);
                // console.log('first',refreshing)

                if(refreshing == key){
                setRefreshing(false);
                }else{
                setRefreshing(true);
                }
                // console.log('last',refreshing)
                }}
                ><Text style={{fontWeight:'bold',textAlign:'center'}}>+</Text>
                </TouchableOpacity>

                <Text style={{marginLeft:5}}>{item.number}</Text>

                <TouchableOpacity
                style={{height:20,
                width:20,
                borderTopWidth:1,
                textAlign:'center'
                }}
                onPress={()=>{
                    if(item.number<2){
                item.number = 1
                    }else{
                item.number = item.number - 1
                }
                // console.log(item)
                // _onRefresh()
                setRefreshing(false);
                // console.log('first',refreshing)

                if(refreshing == key){
                setRefreshing(false);
                }else{
                setRefreshing(true);
                }
                // console.log('last',refreshing)
                }}
                ><Text style={{fontWeight:'bold',textAlign:'center'}}>-</Text>
                </TouchableOpacity>
                <TouchableOpacity
                style={Styles.ord_but}
                onPress={()=>{
                    let indexing = (cartItems.indexOf(item))
                    cartItems.splice(indexing,1)
                    // _onRefresh()
                setRefreshing(false);
                // console.log('first',refreshing)

                if(refreshing == key){
                setRefreshing(false);
                }else{
                setRefreshing(true);
                }
                // console.log('last',refreshing)
                }}
                >
                    <Text>Cancel</Text>
                </TouchableOpacity>
            </View>
                
                }
            /></View>
            {/* <List/> */}

            <View
            style={{
                position:'absolute',
                backgroundColor:'#FFFFFF',
                bottom:0,
                height:90,
                width:'115%',
                left:0
            }}>
            <TouchableOpacity
            style={{
                borderWidth:1,
                height:40,
                width:'90%',
                left:'4.5%',
                marginTop:20,
                justifyContent:'center',
                borderColor:'brown',
                borderRadius:10,
                textAlign:'center',
                backgroundColor:'#FFFFFF',
            }}
            onPress={()=>{
                navigation.navigate('pushOrder',cartItems)
            }}
            ><Text style={{textAlign:'center'}}>Go to Checkout</Text></TouchableOpacity>
            </View>
        </SafeAreaView>
    );
  }

const Styles = StyleSheet.create({
    ord_box:{
        borderWidth:1,
        padding:10,
        marginTop:50,
        borderRadius:10
    },
    ord_but:{
        borderWidth:1,
        paddingTop:10,
        width:100,
        borderColor:'brown',
        paddingBottom:10,
        textAlign:'center',
        paddingLeft:20,
        paddingRight:20,
        borderRadius:5,
        marginLeft:200,
        marginTop:-50
    }
})
export default cart;
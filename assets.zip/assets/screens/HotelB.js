import React, { Component } from 'react';
import {
  View,
  FlatList,
  Image,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  Button,
  RefreshControl,
  Alert
} from 'react-native';
import LoadingIcon from '../components/loader';
import cart from './cart';


var cartList=[]
//test

// function cartFun(){
// if(cartList.indexOf(cartObj)!=(-1)){
//   console.log(cartList.indexOf(cartObj))
//   alert('in array')
//   cartList[cartList.indexOf(cartObj)].number = (cartList[cartList.indexOf(cartObj)].number + 1);
// }else{
//   cartObj.number = 1;
//   cartList.push(cartObj);
// }
// console.log(cartList)
// }

let hotel;
let hotelName;
let ActHotelName;


function filter(text,list,control){
  let filList;
  control = JSON.parse(control)
  if(text == "All"){
    list = control;
    return(list)
  }else{
  list = [];
  for (let y=0;y<control.length;y++){
  if(text == control[y].Category){
    filList = control.splice(y,1)
    list.push(filList[0])
  }else{
  }
}
if (list == ''){
  list = control
  
  alert(`no data found for ${text}`)
}else{
}
return(list)
}
}


class HotelB extends Component {
  constructor(props,route) {
    super(props);
    hotel = props.route.params.HotelLink
    hotelName = props.route.params.HotelName
    
    if(hotelName == 'orders' ){
      ActHotelName = 'Ellegant'
    }
    if(hotelName == 'HotelA' ){
      ActHotelName = 'Kibali Fast Foods'
    }
    if(hotelName == 'HotelB' ){
      ActHotelName = 'Happy House Cafe'
    }
    if (props.route.params.cartListw == ''){
      cartList =[]
    }else{
    cartList = JSON.parse(props.route.params.cartListw)}
    // console.log('this is the first cart',cartList)
    this.state = {
      refreshing: false,
      IconAnimating: true,
      package: [],
      listDisp:[],
      cart:[]
    };
    if(this.state.cart == ''){

    }else{
      cartList = this.state.cart
    }
  
  };

  fetchMovies() {
    fetch(hotel)
      .then((response) => response.json())

      .then((responseJson) => {
        this.setState({
          IconAnimating:false,
          package: responseJson,
          listDisp: responseJson,
           });
})
      .catch((error) => {
        alert('sorry, something went wrong');
      });
  }

  _onRefresh = () => {
    this.setState({refreshing: true});
    fetch(hotel)
      .then((response) => response.json())
    
      .then((responseJson) => {
        this.setState({
          IconAnimating:false,
          refreshing:false,
          package: responseJson,
           });
        console.log('jsonresponse',responseJson);
})
      .catch((error) => {
        alert('sorry, something went wrong');
      });
  }
  UNSAFE_componentWillMount() {
    this.fetchMovies();
  }
  __onRefresh = () => {
    this.setState({refreshing: true});
    this.setState({refreshing: false});
  }
  renderListItem = ({ item }) => (
    <View key={item.ID}>
      <TouchableOpacity
      onPress={()=>{
        var cartObj = {
          ListID:cartList.length +1,
          name:item.Name,
          ID:item.ID,
          price:item.Price,
          hotel:hotelName,
          number:1
        }
        // console.log('cartlist',cartList)

        let index ;
        if (cartList != ''){
          for(let i=0;i<cartList.length;i++){
            if(cartList[i].name == cartObj.name){
              index = i
            }else{
            }
          }

          if(index>-1){
            cartList[index].number = cartList[index].number +1;
          }else{
            cartList.push(cartObj)
          }
        }else{
        cartList.push(cartObj)
      }
        this.setState({cart:cartList})
        

      
        Alert.alert(
          "Item added to cart.",
          "Do you want to continue shopping?",
          [
            {
              text: "Yes",
            },
            {
              text: "No",
              onPress: () => {
                this.props.navigation.navigate('cart',cartList)
              },
            },
          ]
        );
        
        }}
    
    
        style={{
          flex: 1,
          alignSelf: 'stretch',
          backgroundColor: '#fff',
          borderRadius: 15,
          borderWidth: 2,
          borderColor: 'brown',
          marginLeft: 5,
          marginRight: 5,
          marginTop:10,
          paddingTop:10,
          paddingBottom:10,
        }}>
        <Image source={{uri: item.Image}}
               style={{width: 300, height: 200,marginLeft:'auto',marginRight:'auto',borderRadius:15}} />
               
          <Text style={{ fontSize: 16,marginTop:20,paddingLeft:15,color: '#000' }}>Name: {item.Name} </Text>
          <Text style={{ fontSize: 16, paddingLeft:15,color: '#000' }}>Categ: {item.Category} </Text>
        <Text
          style={{
            color: '#007aff',
            paddingLeft:15,
            fontSize: 16,
            fontWeight: '600',
            paddingTop: 10,
            paddingBottom: 10,
          }}>
          Price: {item.Price}
        </Text>
      </TouchableOpacity>
    </View>
  );

  render() {
    // console.log(this.props.route)
    // console.log(cartList)
    return (
      <View style = {{padding:10,paddingTop:40}}>
      <View style ={Styles.header}>
          <TouchableOpacity  onPress={() => this.props.navigation.navigate('Home',cartList)} >
          <Image style={{ height:25, width:25,marginLeft:20}} source={require('../images/back.png')}/>
          </TouchableOpacity>
          <Text
          style={{
              fontWeight:'bold',
              fontSize:18,
              paddingLeft:45,
              borderRadius:10,
              paddingRight:60,
              paddingTop:10,
              paddingBottom:10,
              justifyContent:'center',
              alignItems:'center',
              width:'75%',
              textAlign:'center'
          }}
          >{ActHotelName}</Text>
      </View>

      <View style={Styles.promo}></View>

      <ScrollView
       style={Styles.menu} 
       showsHorizontalScrollIndicator={false}
       horizontal={true}
       >

       
<TouchableOpacity 
          style={Styles.button}
          onPress={()=>{
            let control = JSON.stringify(this.state.package)
            this.state.listDisp = filter("All",this.state.listDisp, control)
            // console.log('final list is',this.state.listDisp)
            this.__onRefresh()
            }}
          >
          <View
          style={Styles.buttonView}
          >
          <Image style={{height:15,width:15,borderRadius:100}} source={require('../images/fries-restaurant.jpg')}/>
          </View>
          <Text style={{
              paddingLeft:5
          }}>all</Text>
          </TouchableOpacity>


          <TouchableOpacity 
          style={Styles.button}
          onPress={()=>{
            let control = JSON.stringify(this.state.package)
            this.state.listDisp = filter("Food",this.state.listDisp, control)
            // console.log('final list is',this.state.listDisp)
            this.__onRefresh()
            }}
          >
          <View
          style={Styles.buttonView}
          >
          <Image style={{height:15,width:15,borderRadius:100}} source={require('../images/food.jpg')}/>
          </View>
          <Text style={{
              paddingLeft:5
          }}>food</Text>
          </TouchableOpacity>

          <TouchableOpacity 
          style={Styles.button}
          onPress={()=>{
            let control = JSON.stringify(this.state.package)
            this.state.listDisp = filter("Stew",this.state.listDisp, control)
            // console.log('final list is',this.state.listDisp)
            this.__onRefresh()
            }}
          >
          <View
          style={Styles.buttonView}
          >
          <Image style={{height:15,width:15,borderRadius:100}} source={require('../images/stews.jpg')}/>
          </View>
          <Text style={{
              paddingLeft:5
          }}>stews</Text>
          </TouchableOpacity>

          
          <TouchableOpacity
          onPress={()=>{
            let control = JSON.stringify(this.state.package)
            this.state.listDisp = filter("Fast ",this.state.listDisp, control)
            // console.log('final list is',this.state.listDisp)
            this.__onRefresh()
            }}
          style={Styles.button}
          >
          <View
          style={Styles.buttonView}
          >
          <Image style={{height:15,width:15,borderRadius:100}} source={require('../images/chips.jpg')}/>
          </View>
          <Text style={{
              paddingLeft:5
          }}>fast</Text>
          </TouchableOpacity>

          
          <TouchableOpacity
          onPress={()=>{
            let control = JSON.stringify(this.state.package)
            this.state.listDisp = filter("Tea",this.state.listDisp, control)
            // console.log('final list is',this.state.listDisp)
            this.__onRefresh()
            }}
          style={Styles.button}
          >
          <View
          style={Styles.buttonView}
          >
          <Image style={{height:15,width:15,borderRadius:100}} source={require('../images/tea.jpg')}/>
          </View>
          <Text style={{
              paddingLeft:5
          }}>tea</Text>
          </TouchableOpacity>

          
          <TouchableOpacity
          onPress={()=>{
            let control = JSON.stringify(this.state.package)
            this.state.listDisp = filter("Drinks",this.state.listDisp, control)
            // console.log('final list is',this.state.listDisp)
            this.__onRefresh()
            }}
          style={Styles.button}
          >
          <View
          style={Styles.buttonView}
          >
          <Image style={{height:15,width:15,borderRadius:100}} source={require('../images/juice.jpg')}/>
          </View>
          <Text style={{
              paddingLeft:5
          }}>juice</Text>
          </TouchableOpacity>
          <View
          style={{width:30}}
          ></View>
          </ScrollView>

<View 
                style={{marginTop:0,height:'90%', paddingBottom:10}}>
                
                <FlatList
        style={{
          marginTop:70,
          paddingBottom:'30%'
        }}
          keyExtractor={(item, index) => item.ID.toString()}
          extraData={this.state.listDisp}
          data={this.state.listDisp}
          renderItem={this.renderListItem}
        refreshControl={
          <RefreshControl
            refreshing={this.state.refreshing}
            onRefresh={this._onRefresh}
        />}/></View>
 
        <Text style={{marginTop:50,marginLeft:'auto',marginRight:'auto'}}>
        <ActivityIndicator size="small" color="#0000ff" animating={this.state.IconAnimating} />;

          </Text>
          <TouchableOpacity
          style={{
            position:'absolute',
              left:'90%',
              top:50,
              height:35,
          }}
          onPress={()=>this.props.navigation.navigate('cart',cartList)}
          >
          <Image style={{height:30,width:30}} source={require('../images/fries.png')}/>
          <View style={{
            height:15,
            width:15,
            borderWidth:1,
            textAlign:'center',
            borderRadius:100,
            marginTop:-35,
            marginLeft:20,
            backgroundColor:'#FFFFFF'
          }}><Text
          style={{
            marginTop:-2,
            textAlign:'center',
            fontSize:12
          }}
          >{cartList.length}</Text></View>
          </TouchableOpacity>
      </View>
    );
  }
}
const Styles = StyleSheet.create({
  header:{
      flexDirection:'row',
      justifyContent:'flex-start',
      alignItems:'center',
      backgroundColor:'white'
  },
  promo:{},
  menu:{
    position:'absolute',
      flexDirection:'row',
      marginTop:95,
      backgroundColor:'white',
      padding:10,
      overflow:'scroll',
      height:57,
      width:'100%',
      marginLeft:'3%'
  },
  button:{
      flexDirection:'row',
      justifyContent:'center',
      borderWidth:1,
      borderColor:'grey',
      padding:15,
      paddingBottom:5,
      paddingTop:5,
      borderRadius:15,
      marginLeft:7

  },
  buttonView:{  
    borderWidth:1,
    borderColor:'grey',
    borderRadius:100,
    height:25,
    width:25,
    justifyContent:'center',
    backgroundColor:'white',
    alignItems:'center',
  }
})
export default HotelB;

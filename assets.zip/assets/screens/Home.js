import React, {useState,useEffect}from 'react'
import {Text,View,SafeAreaView,StyleSheet, ScrollView,Image, RefreshControl, ImageBackground, TouchableOpacity, Alert} from 'react-native';
import { useNavigation } from '@react-navigation/core';

let cartListw
let hotelState =[{MessageA:'Closed'},{MessageB:'Closed'},{MessageC:'Closed'}];
let stateColorA;
let stateColorB;
let stateColorC;
let stringA = 'hotelState.MessageA';
export default function HomeScreen({route,navigation}){
    let hotelList = [{
        hotel:'HotelB'
    }]
    let [hotelStateOn, setHotelStateOn] = useState('');
    // console.log(route)
    if(route.params != undefined){
        cartListw = JSON.stringify(route.params)

        // console.log(cartListw)
    }else{
        cartListw = []
        // console.log('route params undefined')
    }
    const [refreshing, setRefreshing] = useState(false);
  
    const onRefresh = () => {
      setRefreshing(true);
      setTimeout(() => {
          fetchFun();
        setRefreshing(false);
      }, 2000);
    };
//     let resk;
//     useEffect(()=>{fetchFun()},[]);

//     function fetchFun (){
//     fetch('https://sheltonnito.000webhostapp.com/c_eatery/hotelState.php')
//     .then((response) => response.json())

//     .then((responseJson) => {
//     console.log(resk = {responseJson})
//         setHotelStateOn(responseJson[0]);
// })
//     hotelState = hotelStateOn;
// }

function fetchFun(){
    fetch ('https://sheltonnito.000webhostapp.com/c_eatery/hotelState.php')
    .then((response)=>response.json())

    .then((responseJson)=>{
        setHotelStateOn(responseJson[0]);
})
    hotelState=hotelStateOn
    // console.log('shelton')
}
// fetchFun();

// class Loading {
//     constructor(){}
//     componentDidMount(){
//         fetchFun();
//     }
// }
// Loading

useEffect(()=>{
    fetchFun();
},[]);


hotelState=hotelStateOn
        // fetchFun();
function Load(){
    if(hotelState){
    return(
        <Text>{hotelState.MessageA} </Text>
    )}else{
        return(
            <Text>Loading...</Text>
        )
    }
}
function LoadB(){
    if(hotelState){
    return(
        <Text>{hotelState.MessageB} </Text>
    )}else{
        return(
            <Text>Loading...</Text>
        )
    }
}
function LoadC(){
    if(hotelState){
    return(
        <Text>{hotelState.MessageC} </Text>
    )}else{
        return(
            <Text>Loading...</Text>
        )
    }
}

    return(
        <SafeAreaView style= {{backgroundColor:"white"}}>
        <ScrollView style = {{padding:10,}} 
        
      refreshControl={
        <RefreshControl refreshing={refreshing} 
          onRefresh={onRefresh} />
      }>
            <View style ={Styles.header}>
                <TouchableOpacity
                style={{marginLeft:'2%'}}
                onPress={()=>{navigation.navigate('About')}}
                >
                <Image style={{ height:50, width:50}} source={require('../images/menuicon-removebg-preview.png')}/>
                </TouchableOpacity>
                <Text
                style={{
                    fontWeight:'bold',
                    fontSize:14,
                    paddingLeft:60,
                    marginLeft:"2%",
                    borderRadius:10,
                    paddingRight:60,
                    paddingTop:10,
                    flexWrap:'nowrap',
                    paddingBottom:10,
                    backgroundColor:'#D3D3D3',
                    justifyContent:'center',
                    alignItems:'center',
                    width:'65%'
                }}
                >Comrade Eatery</Text>
                <TouchableOpacity
                style={{
                    marginLeft:'15%',
                    right:-25 ,
                    position:'absolute',
                    top:10
                }} 

                onPress={()=>navigation.navigate('delivery')}
                >
                <Image style={{height:30,width:30}} source={require('../images/fries.png')}/>
                </TouchableOpacity>
            </View>

            <View style={{height:20}}></View>
            <TouchableOpacity style={Styles.hotel}
            onPress={() =>{ 
                
                if(hotelState.MessageA == 'Open'){
                navigation.navigate("HotelB",{HotelLink:'https://sheltonnito.000webhostapp.com/c_eatery/pullmenu.php',HotelName:'orders',cartListw:cartListw})
                }
                else{
                    Alert.alert('...','Hotel Closed')
                    console.log('...','Hotel Closed')
                }}}
            >
                <Text style={Styles.time}>25-30 min</Text>
            <Image  style={{height:200,width:'100%',borderRadius:20}} source={require('../images/burger-restaurant-2.jpg')}/>
                <Text style={Styles.time}>25-30 min</Text>

            <Text style={{
                fontWeight:'bold',
                fontSize:15,
                marginTop:20
                
            }}>Ellegant</Text>

            <View style={{justifyContent:'flex-end',flexDirection:'row',marginTop:10}}>
             <Image style={{height:20,width:20,marginRight:3}} source={require('../images/star-removebg-preview.png')}/>
            <Text style={Styles.details}>4.7</Text>
            <Text style={Styles.details}>All</Text>
            <Text style={Styles.detailsState}>{Load()} </Text>
            {/* <Load></Load> */}
            </View>
            </TouchableOpacity>

            <TouchableOpacity style={Styles.hotel}
            onPress={() => {
                if(hotelState.MessageB == 'Open'){
                navigation.navigate("HotelB", {HotelLink:'https://sheltonnito.000webhostapp.com/c_eatery/pullmenuB.php',HotelName:'HotelA',cartListw:cartListw})
                }else{
                    Alert.alert('...','Hotel Closed')
                    console.log('...','Hotel Closed')
                }}}>
            <Image  style={{height:200,width:"100%",borderRadius:30}} source={require('../images/fries-restaurant.jpg')}/>
            
            <Text style={Styles.time}>25-30 min</Text>

            <Text style={{
                fontWeight:'bold',
                fontSize:15,
                marginTop:20
                
            }}>Kibali Fast Food</Text>

            <View style={{justifyContent:'flex-end',flexDirection:'row',marginTop:10}}>
             <Image style={{height:20,width:20,marginRight:3}} source={require('../images/star-removebg-preview.png')}/>
            <Text style={Styles.details}>4.7</Text>
            <Text style={Styles.details}>All</Text>
            <Text style={Styles.detailsState}>{LoadB()}</Text>
            </View>
            </TouchableOpacity>

            
            <TouchableOpacity style={Styles.hotel}
            
            onPress={() =>{
                // <]2zAhRP4yw?#C)G
                if(hotelState.MessageC == 'Open'){
                navigation.navigate("HotelB",{
                HotelLink:'https://sheltonnito.000webhostapp.com/c_eatery/pullmenuC.php',
                HotelName:'HotelB',
                cartListw:cartListw
                })
                }else{
                    Alert.alert('...','Hotel Closed')
                    console.log('...','Hotel Closed')
                }
                }}>
            <Image  style={{height:200,width:"100%",borderRadius:30}} source={require('../images/nasi-lemak.jpg')}/>
                <Text style={Styles.time}>25-30 min</Text>

            <Text style={{
                fontWeight:'bold',
                fontSize:15,
                marginTop:20
                
            }}>Happy House Cafe</Text>

           <View style={{justifyContent:'flex-end',flexDirection:'row',marginTop:10}}>
             <Image style={{height:20,width:20,marginRight:3}} source={require('../images/star-removebg-preview.png')}/>
            <Text style={Styles.details}>4.7</Text>
            <Text style={Styles.details}>All</Text>
            <Text style={Styles.detailsState}>{LoadC()}</Text>
            </View>
            </TouchableOpacity>
            <View style={{height:100}}></View>
        </ScrollView>

        </SafeAreaView>
    )
}

const Styles = StyleSheet.create({
    header:{
        flexDirection:'row',
        justifyContent:'flex-start',
        alignItems:'center',
        marginTop:40
    },

    hotel:{
        width: '100%',
        borderColor:'grey',
        borderWidth:1,
        marginTop:20,
        padding:10,
        borderRadius:20

    },
    image:{
        height: 200,
        width: 100,
        resizeMode: 'contain',
        borderBottomLeftRadius: 30,
        borderBottomRightRadius: 30,
        borderTopRightRadius: 30,
        borderTopLeftRadius: 30,
        overflow: 'hidden',
    },
    time:{
        backgroundColor:'white',
        position:'absolute',
        display:'flex',
        alignItems: 'center',
        justifyContent:'center',
        marginTop:190,
        borderTopRightRadius:15,
        paddingLeft:10, 
        height:30,
        width:100,
        paddingRight:15,
        fontWeight:'bold',

    },
    details:{
        color:'blue',
        marginRight:15
    },
    
    detailsState:{
        color:'blue',
        marginRight:15
    },
})
import React from "react";
import {
    View,
    Text,
    Image,
    TouchableOpacity,
    FlatList,
    Alert
}from 'react-native';
import { SafeAreaView } from "react-native-safe-area-context";

export default function delivery(route){

    let orderItems;
    let resMessage;
    let DelPerson;
    let DelNumber;
    let succMess;
    let Success;
    if(route.route.params == undefined){
        orderItems = [];
        resMessage = '';
        DelPerson = '';
        DelNumber = '';
        Success = 'Please Make an order';
    }else{
         orderItems = route.route.params.cartitems
         resMessage = route.route.params.resmessage
         DelPerson = route.route.params.DelPerson
         DelNumber = route.route.params.DelNumber
         Success = route.route.params.Success
}
     console.log(resMessage)
    //  console.log(route.route.params.Success)
     if (resMessage == 'Server Error... please try again later'){
         succMess = ''
         Success =''
     }else{
         succMess = Success;
     }
     let Price = 0;
     for (let i=0;i<orderItems.length;i++){
       Price = Price + (Number(orderItems[i].price.match(/\d+/)[0])*orderItems[i].number)
     }
return(
    <SafeAreaView>
    <View 
    style= {{
        alignItems:'center',
        justifyContent:'center',
        width:"100%",
        marginTop:"60%",
        height:100
    }}
    >
    {/* <TouchableOpacity  style ={{borderWidth:1}} onPress={()=>route.navigation.goBack()}><Text>go back</Text></TouchableOpacity> */}
    <TouchableOpacity
    >
    <TouchableOpacity
    style={{
        marginLeft:200
    }}
    onPress={()=>{
          route.navigation.reset({
              index: 0,
              routes: [{name: 'Home', params: undefined}],
              });}}
    >
      <Image style={{
        height:35,
        width:35
      }} source={require('../images/download__26_-removebg-preview.png')}/></TouchableOpacity>

<View style={{marginTop:"40%"}}></View>

    </TouchableOpacity>

    <Text style={{
        fontWeight:'bold'
    }}>{resMessage}</Text>
        <Text
        style={{
            fontWeight:'bold'
        }}
        >{succMess}</Text>

        <View
        style={{
            borderLeftWidth:1,
            paddingLeft:10,
            marginLeft:-40,
            marginTop:10
        }}
        >
    <Text>Order List : </Text>
    <FlatList

        data={orderItems}
        keyExtractor={orderKey => orderKey.ListID.toString()}
        renderItem={({item})=>
        <Text>{item.name} @{item.price.match(/\d+/)[0]} x {item.number}</Text>
        }
    />
        <Text
        style={{marginTop:0}}
        >Total : {Price} + delivery</Text>
        </View>

        <Text 
        style={{
            marginTop:30,
            marginLeft:-50
        }}
        >Delivery Agent : </Text>
        <View
        style ={{
            textAlign:'left',
            borderLeftWidth:1,
            paddingLeft:10,
            marginTop:10
        }}
        >
        <Text>{DelPerson}</Text>
        <Text>{DelNumber}</Text>
        </View>
    </View>
    </SafeAreaView>
)
}
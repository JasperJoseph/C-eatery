import React, { Component,useState,useEffect } from 'react';
import {
  View,
  Button,
  FlatList,
  StyleSheet,
  Image,
  Text,
  TouchableOpacity,
  ActivityIndicator,
  SafeAreaView,
  TextInput,
} from 'react-native';
import axios from 'axios';




 
  function pushOrder({ route, navigation }) {
    /* 2. Get the param */  
  const [FullName,setFullName] = useState("");
  const [RoomNo,setRoomNo] = useState("");
  const [PhoneNo,setPhoneNo] = useState("");
  const [Quantity,setQuantity] = useState("");
  const [ProdName,setProdName] = useState("");
  let cartItems = route.params
  const [isSubmit, setisSubmite]=useState(false);
  //calculate price

  let Price = 0;
  for (let i=0;i<cartItems.length;i++){
    Price = Price + (Number(cartItems[i].price.match(/\d+/)[0])*cartItems[i].number)
  }
  useEffect(()=>{
    const authenticate = async()=>{
      axios
      .post(
        "https://sheltonnito.000webhostapp.com/c_eatery/pushOrder.php",
        JSON.stringify({
          FullName: FullName,
          PhoneNo: PhoneNo,
          RoomNo:RoomNo,
          Quantity:Quantity,
          ProdName:ProdName,
        })
      )
      .then((response)=>{
        setisSubmite(false);
        navigation.navigate('delivery',{
          cartitems:cartItems,
          resmessage:response.data[0].Message,
          DelPerson:response.data[0].DelPerson,
          DelNumber:response.data[0].DelNumber,
          Success:response.data[0].Success
        });
      })
      .catch((err)=>{
      });
    };
    if (isSubmit)   authenticate();
  },[isSubmit])
    // const { name,ID,Price,hotel } = route.params
    
    return (
      <SafeAreaView style={{ flex: 1, alignItems: 'center', justifyContent: 'center' ,marginTop:40}}>

      <Text style={{position:"absolute",top:'45%'}}>
      <ActivityIndicator size="small" color="#0000ff" animating={isSubmit} />;
      </Text>

      <TouchableOpacity style={{
        position:'absolute',
        top:40,
        right:40
      }}  onPress={() => navigation.navigate('Home',cartItems)} ><Image style={{
        height:35,
        width:35
      }} source={require('../images/download__26_-removebg-preview.png')}/></TouchableOpacity>
      <TouchableOpacity style={{
        position:'absolute',
        top:40,
        left:40}}
        onPress={() => navigation.goBack()} ><Image style={{
        height:35,
        width:35,
      }} source={require('../images/back.png')}/></TouchableOpacity>
      <View style={{
        borderWidth:1,
        borderColor:'grey',
        padding: 10,
        width:'60%'
      }}>
        <Text
        style={{
          borderBottomWidth:1,
          borderBottomColor:'grey',
          paddingBottom:5
        }}
        >Product Details</Text>
        <Text style={{
          paddingTop:5
        }}></Text>
        <View>
          <FlatList
          data={cartItems}
          keyExtractor={itemID => itemID.ListID.toString()}
          renderItem={({item})=>
          <Text>{item.name} @{item.price.match(/\d+/)[0]} x {item.number}</Text>}

          />
        </View>
        <Text>price: {Price} + delivery fee</Text>
      </View>

      
        <View style={{
          marginTop:20,
          width:'60%',
        }}>
          <TextInput
          placeholder='name'
          onChangeText={(text)=>setFullName(text)}
          style={styles.input}
          />
          
          <TextInput
          placeholder='RoomNo'
          onChangeText={(text)=>setRoomNo(text)}
          style={styles.input}
          />
          
          
          <TextInput
          placeholder='phone'
          onChangeText={(text)=>setPhoneNo(text)}
          keyboardType='numeric'
          style={styles.input}
          />
          <TextInput
          placeholder='Quantity/More Details'
          onChangeText={(text)=>setQuantity(text)}
          style={styles.input}
          
          />
        </View>
        <TouchableOpacity style={{
          borderWidth:1,
          borderColor:'grey',
          marginTop:40,
          padding:7,
          paddingRight:15,
          paddingLeft:15
        }} onPress={() => {
          if(FullName === ''|| RoomNo === '' || PhoneNo === '' || Quantity === ''){
            alert('Failed! - Empty Field')
            
          }else{
            if(cartItems != ''){
          setProdName(cartItems),setisSubmite(true)
          }else{
            alert('Failed! - no item in cart')
          }}
           }} ><Text>Push Order</Text></TouchableOpacity>
      </SafeAreaView>
    );
  }
  const styles= StyleSheet.create({
    input:{
      borderWidth:1,
      borderColor:'grey',
      width:'100%',
      padding:5,
      marginTop:10

    }
  })
  export default pushOrder
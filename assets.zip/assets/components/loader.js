import React from 'react';
import { ActivityIndicator } from 'react-native';

const LoadingIcon = () => <ActivityIndicator size="small" color="#0000ff" animating={true} />;
export default LoadingIcon;
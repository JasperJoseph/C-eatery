import React,{Component} from "react";
import {Text} from 'react-native'

export default  function bottomTab() {
    return(
        <Text 
        style={{
            borderWidth:2,
            borderColor:'red'
        }}>bottom tab</Text>
    )
}